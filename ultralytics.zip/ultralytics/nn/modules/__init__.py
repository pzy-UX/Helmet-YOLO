# Ultralytics YOLO 🚀, AGPL-3.0 license
"""
Ultralytics modules. Visualize with:

from ultralytics.nn.modules import *
import torch
import os

x = torch.ones(1, 128, 40, 40)
m = Conv(128, 128)
f = f'{m._get_name()}.onnx'
torch.onnx.export(m, x, f)
os.system(f'onnxsim {f} {f} && open {f}')
"""

from .block import (C1, C2, C3, C3TR, DFL, SPP, SPPF, Bottleneck, BottleneckCSP, C2f, C3Ghost, C3x, GhostBottleneck,
                    HGBlock, HGStem, Proto, RepC3, SeBlock, drop_connect, MBConvBlock, stem, SE, ECA, h_sigmoid,
                    h_swish, CoordAtt, SimAM, SplitAttention, S2Attention, Channel_Att, NAMAttention,
                    CrissCrossAttention, GAMAttention, SKAttention, ShuffleAttention, DoubleAttention, BasicConv,
                    BasicRFB, CoTAttention, EffectiveSEModule, GlobalContext, GatherExcite, MHSA, ParNetAttention,
                    ParallelPolarizedSelfAttention, SpatialGroupEnhance, SequentialPolarizedSelfAttention, BasicConv_T,
                    ZPool, AttentionGate, TripletAttention, cbam, MBConvBlock_cbam, C2f_CA, CA_Bottleneck, VanillaBlock,
                    space_to_depth, ASFF2, ASFF3, ScConv, VanillaBlock_OD, LSKblock, BiFPN_Add2, BiFPN_Add3, EVCBlock, MBConvBlock_act, C2f_SE, Silence)
from .conv import (CBAM, ChannelAttention, Concat, Conv, Conv2, ConvTranspose, DWConv, DWConvTranspose2d, Focus,
                   GhostConv, LightConv, RepConv, SpatialAttention, ODConv2d, Conv_act)
from .head import Classify, Detect, Pose, RTDETRDecoder, Segment
from .transformer import (AIFI, MLP, DeformableTransformerDecoder, DeformableTransformerDecoderLayer, LayerNorm2d,
                          MLPBlock, MSDeformAttn, TransformerBlock, TransformerEncoderLayer, TransformerLayer)
from ultralytics.nn.modules.Yolov9 import RepNCSPELAN4, ADown, SPPELAN, CBFuse, CBLinear, Silence
from ultralytics.nn.modules.senetv2 import SaELayer


__all__ = [
    'Conv', 'Conv2', 'LightConv', 'RepConv', 'DWConv', 'DWConvTranspose2d', 'ConvTranspose', 'Focus', 'GhostConv',
    'ChannelAttention', 'SpatialAttention', 'CBAM', 'Concat', 'TransformerLayer', 'TransformerBlock', 'MLPBlock',
    'LayerNorm2d', 'DFL', 'HGBlock', 'HGStem', 'SPP', 'SPPF', 'C1', 'C2', 'C3', 'C2f','C2f_CA', 'C3x', 'C3TR', 'C3Ghost',
    'GhostBottleneck','CA_Bottleneck','Bottleneck', 'BottleneckCSP', 'Proto', 'Detect', 'Segment', 'Pose', 'Classify',
    'TransformerEncoderLayer', 'RepC3', 'RTDETRDecoder', 'AIFI', 'DeformableTransformerDecoder',
    'DeformableTransformerDecoderLayer', 'MSDeformAttn', 'MLP','SeBlock','drop_connect','stem','MBConvBlock','MBConvBlock_cbam','SE','ECA',
'h_sigmoid','h_swish','CoordAtt','SimAM','SplitAttention','S2Attention','Channel_Att','NAMAttention','CrissCrossAttention',
'GAMAttention','SKAttention','ShuffleAttention','DoubleAttention','BasicConv','BasicRFB','CoTAttention',
'EffectiveSEModule','GlobalContext','GatherExcite','MHSA','ParNetAttention','ParallelPolarizedSelfAttention',
'SpatialGroupEnhance','SequentialPolarizedSelfAttention','BasicConv_T','ZPool','AttentionGate','TripletAttention','cbam','VanillaBlock',
'space_to_depth','ASFF2', 'ASFF3', 'ScConv', 'ODConv2d', 'VanillaBlock_OD', 'LSKblock', 'BiFPN_Add2', 'BiFPN_Add3', 'EVCBlock', 'MBConvBlock_act', 'RepNCSPELAN4', 'ADown', 'SPPELAN', 'Conv_act',
'C2f_SE','Silence','SaELayer']#SeBlock及以后添加
#SE及之后是注意力机制模块
